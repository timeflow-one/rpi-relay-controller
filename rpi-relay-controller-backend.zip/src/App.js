import 'reflect-metadata'
import Container, { Inject, Service } from 'typedi'
import { ControllersServer } from './ControllersServer'
import { Constants } from './utils/Constants'
import { LockController } from './controllers/LockController'
import { createConnection } from 'typeorm'
import { DirectLockManager } from './managers/DirectLockManager'
import { LocksController } from './controllers/LocksController'
import { RelaysController } from './controllers/RelaysController'
import { initLocks } from './utils/LocksUtil'

@Service()
class App {
  /**
   * @private
   * @type {import('./models/SimpleServer').SimpleServer}
   */
  @Inject(() => ControllersServer)
  server

  /**
   * @public
   */
  async init () {
    this.server.init()
  }

  /**
   * @public
   * @param {number} port
   */
  async start (port) {
    this.server.start(port)
  }

  /**
   * @public
   */
  async stop () {
    this.server.stop()
  }
}

async function main () {
  // create connection to database
  await createConnection()
  // lock managers
  Container.set(Constants.LOCKS_MANAGERS, [
    Container.get(DirectLockManager)
  ])
  // koa controllers list
  Container.set(Constants.CONTROLLERS, [
    Container.get(LockController),
    Container.get(LocksController),
    Container.get(RelaysController)
  ])
  // init locks
  await initLocks(Container.get(Constants.LOCKS_MANAGERS))

  const app = Container.get(App)
  process.on('SIGINT', () => app.stop())
  await app.init()
  await app.start(Number(process.env.PORT))
}

main()
