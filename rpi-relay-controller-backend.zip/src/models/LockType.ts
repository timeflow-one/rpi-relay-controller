export enum LockType {
  DIRECT = 'direct',
  COMPOSITE = 'composite'
}
