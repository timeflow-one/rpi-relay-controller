export const Constants = {
  CONTROLLERS: 'controllers_list',
  DATABASE: 'relays_database',
  LOCKS_MANAGERS: 'relays_managers'
}
