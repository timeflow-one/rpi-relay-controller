# RPI relay controller

Документация: [ссылка](https://orblrus.atlassian.net/wiki/x/AYD4G)
